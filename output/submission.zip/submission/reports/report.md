# Consumer sentiment, prices and media

Victor Chen

FRE-GY 7871

Instructor: Dr. Daniel Rodriguez

GitHub: [github.com/victor4628/ai-media-consumer-sentiment](https://github.com/victor4628/ai-media-consumer-sentiment)

## 1. Consumer sentiment, prices and media

Six research questions | Research cutoff: 16 October 2026

Main finding. The apparent gap between economic conditions and consumer sentiment changes substantially when the economic benchmark includes accumulated prices and recent sentiment. Media tone contains a promising predictive signal in one controlled specification, but its benefit reverses in the smallest, most strictly covered sample.

RQ1 — How can we measure bias in coverage? Separate economic tone from emotional language, political attribution, topic salience and price framing. In the eligible sample, emotional or mixed language appears in 86.1% of X posts versus 23.9% of news headlines. This is a content contrast, not a population estimate of platform bias.

RQ2 — Does bias depress sentiment before the midterms? Our last observation is August 2026, before the final campaign weeks. The economy-only model predicts 66.1 against observed ICS of 51.7; adding media tone predicts 60.8. That smaller forecast gap does not identify a causal media effect.

RQ3 — What do unemployment, inflation and GDP explain? Relative to 2017–2019, the June–August 2026 mean ICS falls 44.9 points. Three indicators account descriptively for 16.7 points. The residual falls from 28.3 to 7.1 points when accumulated prices enter the same descriptive analysis.

RQ4 — Which perceptual mechanisms can we measure? We observe content proxies for negativity bias, availability bias, confirmation bias and anchoring to past prices. We do not observe individual exposure, recall, prior beliefs or personal reference prices.

RQ5 — Does media improve prediction? Almost no improvement follows a baseline with prior sentiment: MAE 4.199 to 4.198. Adding seasonality and survey-mode controls produces 3.857 to 3.527, compared with 3.725 for simply carrying forward prior sentiment.

RQ6 — What contradicts a media-bias explanation? A stronger price benchmark shrinks the residual; the media benefit reverses under the strictest coverage rule; extra content features together worsen prediction. These are substantive challenges to a strong media-only account.

Study base. 1,473 candidate items were coded directly by GPT; 230 US-relevant economic news headlines and 829 X posts qualify for the primary analysis. Media cover October 2019–July 2026. The matched forecast comparison contains 40 months from January 2023–August 2026. No new data were purchased for this revision.

## 2. How Michigan consumer sentiment is calculated

Five survey questions combine views of personal finances and the wider economy.

![Monthly published sentiment and component series, January 2010–August 2026. Descriptive current-vintage series; not used as unreleased origin-time inputs.](final_gpt_v3/figures/ics_components.png)

The University of Michigan Index of Consumer Sentiment (ICS) uses five questions: personal finances compared with a year ago; expected personal finances a year ahead; expected business conditions over the next year; expected business conditions over the next five years; and whether now is a good time to buy major household goods. Favorable and unfavorable response categories are defined separately for each question. [1]

Relative score: x_i = round(100 + percentage favorable_i − percentage unfavorable_i). Index: ICS = (x_1 + x_2 + x_3 + x_4 + x_5) / 6.7558 + 2. Round each relative score first; the denominator and constant place the combined scores on the historical index scale. This is not the percentage of respondents who feel optimistic. [1]

Current Economic Conditions combines the first and fifth questions; Consumer Expectations combines the second, third and fourth. Two current-condition questions and three expectation questions therefore enter the overall index. The plotted components help distinguish a weak present assessment from weak expectations, without attributing either to a specific media source.

Sampling and survey mode also matter. Michigan phased from telephone to web interviews between April and July 2024. Our forecasting sensitivity includes a fixed ramp of 0.25, 0.50, 0.75 and 1.00 over those months plus seasonal sine/cosine terms. This is a coarse control, not proof that method changes explain the sentiment decline. [2,3]

## 3. RQ1 | What do our measures show?

The strongest platform contrast is emotional language, rather than negative tone alone.

![Pooled eligible-item shares. Emotional includes mixed style; political blame and price levels each include their “both” category. Topics may overlap.](final_gpt_v3/figures/content.png)

GPT assigned categorical judgments for economic relevance and US scope, economic tone, language style, topics, household/national framing, price levels versus price changes, current/future focus, and political blame or credit. Negative economic news can be expressed factually; a positive economic claim can still use emotional or partisan language. We measure these separately.

The corpus contains 489 candidate news headlines and 984 X posts. The primary inclusion rule requires economic substance, clear US relevance and availability before the next monthly forecast origin. It retains 230 news headlines and 829 X posts. News excludes 26 non-economic, 89 foreign and 144 uncertain-US items; X excludes 81, 22 and 52 respectively. Uncertain scope is excluded rather than silently treated as US.

Negative tone differs by 7.9 percentage points, while emotional or mixed language differs by 62.2 points. Political blame, including both blame and credit, differs by 26.9 points. Within positive-tone items, emotional or mixed language is still 77.5% for X versus 11.3% for news. The rhetorical contrast is not simply a consequence of X containing more negative items.

These shares describe the retrieved items. The news and X selections are not matched on identical events, audience exposure or author composition. They cannot establish distortion relative to objective economic facts or a causal platform effect. Five numerical claims in four purposively selected historical headlines matched contemporaneous official releases; that limited check is not an accuracy estimate for the 246 eligible numerical claims.

## 4. RQ2 | Is media depressing sentiment?

A lower forecast gap is evidence of association; the causal quantity is not identified.

![Forty matched forecast months. Lines connect available test observations; four calendar months are absent. The gray band belongs only to the method-controls-plus-tone forecast.](final_gpt_v3/figures/forecast_gap.png)

We compare actual sentiment with forecasts based on information released before each target month. In August 2026, observed ICS is 51.7, the three-indicator forecast is 66.13, and the same model with prior-month news and X tone gives 60.83. Carrying forward the most recently available ICS gives 55.2. The economy-only benchmark therefore leaves a much larger gap than a simple memory benchmark.

It would be incorrect to call the 5.30-point difference between the two model predictions a measured depressive effect of media. Media may report the same price pressure consumers experience; economic disappointment may generate negative posts; the retrieval process may change alongside elections. None of these possibilities is separated by aggregate monthly prediction.

The shaded band is constructed sequentially from the 95th percentile of earlier absolute out-of-sample errors, using only errors whose target values were released by the current origin. It starts after at least 12 calibration errors. It is an empirical prediction band, not a causal confidence interval or a guarantee of 95% coverage under dependence.

For memory plus method controls plus tone, 28 months have bands; empirical coverage is 96.4%, with mean width 15.05 points. These small-sample diagnostics should accompany point forecasts. The media archive ends in July 2026 and predicts through August. We have no evidence here about the final election weeks or election outcomes.

## 5. RQ3 | How much do three indicators explain?

Unemployment, annual inflation and real GDP growth leave a large descriptive residual.

![Monthly observed ICS and full-sample fitted values. The price-level regressor uses December 2008 as its fixed base so it is available across the 200-month estimation window.](final_gpt_v3/figures/macro_trend.png)

The accounting exercise is ordinary least squares with an intercept, fitted to 200 monthly observations from January 2010 to August 2026. Regressors are unemployment, PCE inflation over the prior year and the latest released annualized quarterly real GDP growth rate. The target is the cutoff-vintage ICS. Origin-available macro releases are used, but fitting the entire window makes this a descriptive exercise rather than an out-of-sample forecast.

The mean ICS falls from 97.04 in 2017–2019 to 52.13 in June–August 2026, a 44.91-point decline. The fitted three-indicator association accounts for 16.66 points: inflation 16.07, unemployment 0.55 and GDP growth 0.03. A 28.25-point residual remains. The in-sample R-squared is 0.502. These components are regression accounting, not independently estimated causal contributions.

Adding accumulated price growth reduces the residual to 7.08 points and raises R-squared to 0.768. Adding a linear time trend instead leaves 17.99 points; adding both real income growth and accumulated prices leaves 5.21. Accumulated prices therefore contain information beyond a simple linear trend in this window, while also potentially absorbing other persistent changes.

Reference choice matters. Using 2015–2019 instead of 2017–2019 changes the three-indicator accounting share from 37.1% to 43.3%. Those shares belong in methodological interpretation, not as headline causal percentages. Residual movement must not be assigned automatically to media, political bias or consumer irrationality.

## 6. RQ3 | Slower inflation is not lower prices

The accumulated shopping bill remains an important competing explanation.

![All 82 media-linked forecast origins. The presentation uses selected readings for a simple visual; the analysis and report plot use the full monthly series. Fixed December 2018 base for this display.](final_gpt_v3/figures/price_pressure.png)

The last pre-August 2026 information set shows PCE prices 27.94% above December 2018, annual PCE inflation of 3.67%, and annual real disposable income growth of 0.52%. The first quantity is a cumulative increase; the second is the current pace of increase. A slower pace does not undo earlier increases. These are the latest available releases at that forecast origin, not claims that all three describe August itself.

This supports examining purchasing power directly. It does not show that consumers irrationally anchor to an old price: high current prices may create a real budget constraint, while changing incomes, wealth, debt, housing costs and expectations can also matter. Different households face different spending baskets, which aggregate PCE cannot identify.

A separate forecast check uses the full macro training history, with 44 common test months. Adding accumulated prices to the economy-only model reduces MAE from 17.108 to 8.712; adding a linear trend reduces it only to 14.148. The nominal block-bootstrap interval for the price improvement is −11.04 to −5.75 points of MAE. This supports price relevance beyond the full-sample fit.

A stronger memory benchmark changes the comparison: adding prices reduces MAE from 4.324 to 3.995, but carrying forward prior sentiment gives 3.618. The price model does not establish a reliable improvement over persistence; its relative interval is −0.29 to +1.02. This 44-month experiment uses a different training sample from the 40-month media experiment. Their absolute errors must not be compared as if generated by identical histories.

## 7. RQ4 | Which mechanisms can we measure?

The archive measures content proxies; consumer mechanisms require individual responses.

Negativity bias — negative economic tone. We can measure how often negative content appears: 45.2% of news and 53.1% of X. Negativity bias itself means people respond more strongly to negative than equivalent positive information. That requires matched facts, exposure and a measured response; content frequency alone does not measure that asymmetry.

Availability bias — topic salience. Prices appear in 25.7% of news and 37.6% of X, with multilabel topics permitted. This measures prominence within our selection. Availability bias requires showing that exposure changes recall or perceived frequency beyond actual conditions. We have no individual exposure or recall observations.

Confirmation bias — political blame. Political blame, including both blame and credit, occurs in 22.6% of news and 49.6% of X. That measures attribution in the message. Confirmation bias requires pre-existing beliefs, source preferences and belief updating after congruent versus incongruent evidence. Party-linked aggregate differences would not by themselves identify individual updating.

Anchoring to past prices — price-level framing. Explicit price-level framing occurs in 8.3% of news and 10.5% of X. Accumulated PCE growth is a separate macro proxy. Neither reveals a respondent’s reference price or whether it persists after income and current purchasing power are held fixed.

What the data can support. We can describe framing, compare coded content, and assess incremental monthly prediction. We cannot estimate these four psychological mechanisms as consumer-level parameters. No respondent microdata or linked media-consumption records are included; no individual age, income, education, party or regional mechanism analysis has been performed.

Next measurement step. Collect reference prices and current budgets alongside media exposure, prior beliefs, recall and subsequent sentiment. Link these measurements within respondents. That design can distinguish rational household pressure from anchoring, and media selection from belief change. No such follow-up has been run in this project.

## 8. RQ5 | Does media add predictive information?

The result depends on whether the benchmark includes memory and survey controls.

![Memory means economy plus prior available sentiment. Household and survey-method controls are separate alternatives. Dashed line: prior-sentiment persistence baseline. MAE units are ICS points.](final_gpt_v3/figures/forecast_benchmarks.png)

All comparisons on this page use the same 40 eligible out-of-sample months. Forecasts use expanding-window ridge regression with fixed penalty 1, an intercept, and means/scales estimated only within each training window. At least 24 eligible training months are required. Target values are drawn from releases available at each forecast origin. Media features refer to the preceding month; no future labels or later target revisions enter training.

The weak economy-only model improves from MAE 11.790 to 11.251 after tone, but this does not establish useful forecasting. With prior sentiment already included, the improvement is effectively zero: 4.199 to 4.198. Adding income and accumulated prices produces 4.030 to 4.004. Their nominal 95% paired intervals for media’s MAE change include zero: respectively [−0.252, +0.274] and [−0.338, +0.286].

The strongest result follows controls for seasonality and the 2024 web-survey transition: 3.857 to 3.527, a change of −0.330 with interval [−0.585, −0.072]. This is a promising conditional signal. However, the advantage over persistence is only −0.198 with interval [−0.791, +0.377], so a reliable win over the simplest strong baseline is not established.

Adding all tone and framing features together worsens MAE to 4.737. The six individual content additions produce MAEs 4.124 (price levels), 4.246 (political blame), 4.080 (emotional language), 4.132 (household scope), 4.498 (price topic) and 4.107 (employment topic). All 15 fixed model specifications remain in the machine-readable results; the report does not select a winner and discard alternatives.

## 9. RQ6 | What challenges the media account?

Stricter coverage changes the sign of the strongest media result.

![Bars in the presentation show the same changes; this figure adds nominal 95% block-bootstrap intervals. Negative changes favor adding media tone.](final_gpt_v3/figures/coverage_robustness.png)

Requiring at least one eligible news headline and three X posts gives 40 test months and a −0.330 MAE change after adding tone to the method-controls model. Requiring two news and five X leaves 25 months and −0.193 [−0.355, −0.028]. Requiring three news and five X leaves only 13 months and +0.299 [−0.128, +0.726]: the point estimate reverses.

The strict filter changes both the training set and evaluated months. It is not a controlled experiment in article count and cannot show that higher coverage causes worse performance. It does show that the predictive conclusion is sensitive to which months the sparse archive supports. News has a median of two eligible items per month and nine months with none; the median for X is ten.

Other perturbations retain the nominal method-controls gain: removing one URL-normalized duplicate gives approximately −0.323; including foreign/uncertain economic items as a geography stress test gives −0.302 on the primary test months; ridge penalties 0.1 and 10 give −0.287 and −0.351. Geography relaxation is deliberately not a US-exposure estimate. The strict-coverage reversal should be reported alongside these supportive checks.

Three further observations weaken a broad media-bias explanation: accumulated prices reduce the descriptive residual; prior sentiment is a strong competitor; and richer content features do not reliably improve prediction. A stronger contradiction would be a prospectively frozen media model failing across well-covered future months, or a sufficiently powered randomized exposure study finding a near-zero effect with a narrow interval.

The paired uncertainty calculation uses contiguous calendar segments and three-month moving blocks, rather than treating missing months as adjacent. Its intervals are nominal, exploratory and not adjusted for the many specifications. Additional robustness checks were added after initial results were read; the extension log records that sequence. No confirmatory significance claim is made.

## 10. Data, coding and reliability audit

The principal uncertainty is measurement and coverage, not just forecast standard errors.

![Eligible monthly counts across 82 media months. All 73 complete monthly rows qualify under the minimum 1-news/3-X rule before the expanding training/test split.](final_gpt_v3/figures/coverage_counts.png)

Sampling uses economy-keyword filters and small historical windows: eight news archive slots on two selected days per month, and two one-hour X search windows. Coding retains at most twelve items per platform per month. The result is a sparse convenience archive, not the universe of US economic reporting. News text is headline-level. Metadata timestamps constrain availability; retrospective collection does not replicate a live historic news feed.

For forecasting, news tone is averaged within observed outlets and then equally across those outlets in each month; X tone is an item mean. Positive, neutral, negative and mixed map to +1, 0, −1 and 0. Pooled descriptive shares instead weight each eligible item equally. These are different estimands. Topic labels overlap; price levels, political blame and emotional-style shares explicitly include their mixed/both categories where defined.

All 1,473 core judgments were assigned directly by GPT in this assistant workflow: 300 original sample judgments plus 1,173 additional judgments. The latter span two coding sessions of 540 and 633. Exact immutable model-version identifiers were not preserved; the data must not be described as a single version-controlled GPT model. Five corrections were logged before the annotation file was sealed; none were changed after the new analysis.

DeepSeek V4 served only as the cached sample reviewer, not as the core coder. The review attempted 300 items (150 news and 150 X), not 300 news. There are 293 valid pairs: tone agreement is 65.2%, Cohen’s kappa 0.539. The original 200-item held-out subset has 196 pairs, 63.8% agreement and kappa 0.522. This reuses earlier calls and judgments, so it is not a new independent replication. No human gold-standard validation was performed; this departs from the original assignment’s human-audit requirement.

A deliberately simple positive-minus-negative word counter agrees with three-class GPT tone in only 36.5% of news and 28.7% of X, with GPT mixed tone mapped to neutral. The dictionary was not tuned or validated; low agreement is disagreement, not evidence GPT is more accurate. FinBERT and RoBERTa were not run in this revision.

Ten constructed politician/source-label swap pairs preserve tone and attribution in all ten visible paired judgments. Pairing was unblinded and coded by the same assistant. This checks rubric consistency on examples; it cannot estimate population bias, independent API repeatability or real-item accuracy. Session cohorts differ in dates and item composition, so cohort contrasts cannot isolate model-version effects.

## 11. What would make the conclusion stronger?

Separate household pressure, selective exposure and changes caused by framing.

Identifying media framing. A proposed study would randomize presentation of identical verified economic facts. A 2 × 2 design could vary negative versus neutral wording and price-level versus inflation-rate emphasis while holding the factual numbers fixed. Randomize source labels separately or balance them across cells. Record pre-exposure sentiment, party beliefs, reference prices and budgets; then measure immediate belief change, recall and delayed sentiment.

Specify the primary contrast, exclusions, smallest meaningful effect and analysis before collecting outcomes. For illustration, detecting a standardized difference of 0.25 with 80% power in one two-group contrast at a two-sided 5% level needs roughly 502 participants in total before attrition, using the normal approximation. A four-cell design needs a separate power calculation, especially for interactions and multiple outcomes. This is a proposed follow-up; no experiment or participant recruitment occurred.

A framing effect in a convenience experiment would not directly quantify the national Michigan ICS effect. That translation needs representative exposure shares, treatment intensity, persistence and population weights. A narrow near-zero effect, stable across informative exposure manipulations, would contradict the proposed framing channel; a noisy null would not settle it.

Prospective forecast plan. Freeze this codebook, primary model, controls, coverage rule and persistence comparison before the next evaluation. At each monthly origin, archive official release vintages, preserve retrieval timestamps and record missingness. Code new content without looking at the next sentiment release, retain both model families’ disagreements for audit, and evaluate only after the target is released. Do not change the story solely because one month looks favorable.

Financial research implication. Forecasts used for consumer demand or portfolio risk scenarios should start with recent sentiment and purchasing-power measures. Add text only when it improves an honestly matched future evaluation. A forecast-gap alert should show the economic benchmark, empirical interval and sample coverage together; a large residual alone is not evidence of a media-driven deterioration in consumer demand.

Practical constraints. This revision performs no new API requests and makes no claim to cover the final campaign weeks. The monitoring dashboard is an offline research view with explicit cutoff and coverage. Refreshing it later requires new source releases and a new evaluation log, not relabeling the existing retrospective experiment as prospective.

## 12. Sources, reproducibility and scope

A public arithmetic reproduction is supplied; private-text extraction and inference are not rerun.

Official measurement sources. [1] University of Michigan, “Index Calculations,” https://data.sca.isr.umich.edu/fetchdoc.php?docid=75432. [2] University of Michigan, 2024 survey-method transition announcement, https://www.sca.isr.umich.edu/files/methodtransitionannouncement2024.pdf. [3] Surveys of Consumers FAQ, https://data.sca.isr.umich.edu/faq.php. These sources define construction and mode changes; they do not support a causal media claim.

Macroeconomic releases. ALFRED/FRED series: UMCSENT (Michigan ICS), UNRATE (BLS unemployment), PCEPI (BEA PCE price index), GDPC1 (BEA real GDP) and DSPIC96 (BEA real disposable personal income). The archive contains 1,005 source snapshots, five series at 201 vintages. Snapshot hashes and release periods are included. Example source: https://alfred.stlouisfed.org/series?seid=UMCSENT. Component series are supplied separately for descriptive plotting.

Content and numerical checks. Existing historical news retrieval and TwitterAPI.io queries supply the convenience archive; no new content is collected in this revision. The frozen core configuration records query windows. reports/final_fact_checks.json lists the five purposive numerical checks, contemporaneous official URLs, and their limited scope. Source documents and presentation source notes must be read with the research cutoff, not interpreted as election forecasts.

Reproduce the statistics. Run python scripts/reproduce_submission.py from the extracted package. It checks included file hashes, original-input identifiers, release snapshots, monthly aggregation, origin-time macro transformations, all fixed forecast specifications and robustness comparisons against frozen results. Run python -m unittest discover -s tests for the test suite. No network calls or API credentials are required. Dependencies are in requirements.txt.

Reproduction boundary. Public exports contain item metadata and categorical labels, not private full text, quotations or rationales. The original annotation seal covers the richer private payload; the export has its own file hash. Original full-input hashes can be compared between label and metadata records, but cannot be recomputed without the private inputs. The single deduplication exclusion is replayed from a frozen ID; duplicate extraction and semantic judgments cannot be independently rerun from this export.

Reading the evidence. Descriptive fits use 200 months; macro-only forecast checks use 44 test months; media-model comparisons use 40 matched test months. These are deliberately separate experiments. No consumer-level mechanism, causal media effect, human-label accuracy, final-election-week result or investment-return backtest is claimed. All reported uncertainty is exploratory; no multiple-specification correction has been applied.

Delivery. Twelve-page report; ten-slide presentation; aligned English speaker script; offline dashboard; frozen analysis and source snapshots; and a package verification log. The final slide summarizes findings. The technical material here supports the presentation without requiring it to become a modeling lecture.

